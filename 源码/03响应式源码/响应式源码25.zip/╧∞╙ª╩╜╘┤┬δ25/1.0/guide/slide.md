# 综述
Slide 详见拔赤的[kissygallery/slide](https://github.com/kissygalleryteam/slide),kissy switchable支持起来较麻烦，加上switchable不再维护，推荐kissygallery/slide，此处提供几个常用响应式slide demo   

## 
1. [在临界点等比缩放slide](http://miaojing.github.io/responsive/1.0/demo/slide/slide-chgwidthheight.html)
2. [在临界点由平铺图片变为slide](http://miaojing.github.io/responsive/1.0/demo/slide/slide-smalltoslide.html)
3. [自适应等比缩放slide](http://miaojing.github.io/responsive/1.0/demo/slide/slide-percent.html)(还有问题)
