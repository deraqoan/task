多级导航使用说明
==================

综述
----
因空间有限，根据实际宽度大小去改变Menu的交互形式;IE6不支持mediaquery及:after写法，所以仅有一个demo支持IE6(用JS控制)。

- [多级导航1](http://miaojing.github.io/responsive/1.0/demo/navigation/Multi-Level/multinav-exIE6-1.htm "")
一级菜单在小屏时，变为menu按钮，点击展开下级菜单，支持多级

- [多级导航2](http://miaojing.github.io/responsive/1.0/demo/navigation/Multi-Level/multinav-exIE6-2.htm "")
一级菜单在小屏时，变为menu按钮，点击展开下级菜单，支持多级，有箭头指示

- [多级导航3](http://miaojing.github.io/responsive/1.0/demo/navigation/Multi-Level/multinav-exIE6-3.htm "")
一级菜单在小屏时，变为menu按钮，在屏幕左侧，点击展开下级菜单，支持多级，menu按钮展开样式不同

- [多级导航4](http://miaojing.github.io/responsive/1.0/demo/navigation/Multi-Level/multinav-exIE6-4.htm "")
一级菜单在小屏时，变为menu按钮，在屏幕左侧，点击展开下级菜单，支持多级，menu按钮展开样式不同，第二级以上有下拉指示单箭头

- [多级导航5](http://miaojing.github.io/responsive/1.0/demo/navigation/Multi-Level/multinav-exIE6-5.htm "")
绚丽的多级菜单，小屏时会有按钮点击事件

- [多级导航6](http://miaojing.github.io/responsive/1.0/demo/navigation/Multi-Level/multinav-exIE6-6.htm "")
一级菜单在小屏时，变为menu按钮，点击展开下级菜单，仅显示第一级

- [多级导航 支持IE6](http://miaojing.github.io/responsive/1.0/demo/navigation/Multi-Level/multinav.htm "")
支持IE6 JS控制行为

