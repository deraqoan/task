多级导航使用说明
==================

综述
----
- Google Map 本身作为Iframe引用可以自动根据iframe 大小适应，仅改变父容器大小即可
- 视频video html5的video标签本身也是可以改变宽度的
- 视频video flash播放器 object也是可以改变宽度大小的，每种播放器加载视频后，是否会显示正常视播放器而定，国内优酷的播放器测试了，可以缩放。而视频比例是一定的，仅改变宽度是不行的，要同时改变宽度和宽度避免视频变形

demo
----
- [Google Map](http://miaojing.github.io/responsive/1.0/demo/media/google-map.htm "Google Map")
- [Video Flash](http://miaojing.github.io/responsive/1.0/demo/media/media-video-flash-youku.htm "Video Flash")
- [Video HTML5](http://miaojing.github.io/responsive/1.0/demo/media/media-video-html5.htm "Video HTML5")

