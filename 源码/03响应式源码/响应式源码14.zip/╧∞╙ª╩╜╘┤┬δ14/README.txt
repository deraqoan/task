Arcana 2.0 by HTML5 UP
html5up.net | @n33co
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)

A business/corporate style responsive site template. It's pretty barebones but should 
go over pretty well for folks wanting to get their serious business on.

Feedback, bug reports, and comments are not only welcome, but strongly encouraged :)

AJ
n33.co @n33co dribbble.com/n33

Credits:

	Images:
		fotogrph (http://fotogrph.com)
	
	Other:
		jQuery (jquery.com)
		html5shiv.js (@afarkas @jdalton @jon_neal @rem)
		5grid.js + 5grid-ui.js (n33.co)