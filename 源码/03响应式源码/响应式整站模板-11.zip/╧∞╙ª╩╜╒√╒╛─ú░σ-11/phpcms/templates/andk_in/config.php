<?php return array (
  'name' => '安妮导刊',
  'author' => 'xyyjk',
  'dirname' => 'andk_in',
  'homepage' => 'http://htm7.net/',
  'version' => '2013.11.06',
  'disable' => 0,
  'file_explan' => 
  array (
    'templates|andk_in|content' => 
    array (
      'category.html' => '文章频道页',
      'category_mix.html' => '文章频道页（有缩略图）',
      'footer.html' => '底部',
      'graphic.html' => '首页底部四块',
      'header.html' => '顶部',
      'index.html' => '网站首页',
      'list.html' => '列表页',
      'list_mix.html' => '列表页（有缩略图）',
      'page.html' => '单网页',
      'show.html' => '文章内容页',
      'sidebar.html' => '侧边栏',
      'tag_list.html' => 'tag',
    ),
    'templates|andk_in|search' => 
    array (
      'footer.html' => '页尾',
      'header.html' => '页头',
      'index.html' => '首页',
      'list.html' => '列表页',
    ),
    'templates|andk_in|' => 
    array (
      'content' => '内容模型',
      'search' => '搜索',
    ),
  ),
);?>